
function reqListener () 
{
var content = this.responseText;

console.log("\n");
var search_value = "_nlm fwb";
var search_key = '"_nll"';
var match_value, indexMatches_value = [];
var match_key, indexMatches_key  = [];


var regExp_search_value = new RegExp(search_value, "gi"); // RegExp used to search pattern, syntax (pattern, modifiers) g - Perform a global match (find all matches rather than stopping after the first match) i - Perform case-insensitive matching
var regExp_search_key = new RegExp(search_key, "gi"); 

	
var array_value=(content.match(regExp_search_value)); 		// The match() method searches a string for a match against a regular expression, and returns the matches, as an Array object.

var array_key=(content.match(regExp_search_key)); 	
	
	// Declaration of array

	 while (match_value = regExp_search_value.exec(content))		// The exec() method returns the matched text if it finds a match, otherwise it returns null.
	 {
      		  indexMatches_value.push(match_value.index);	// Index of match (required search (_nlm fwb)) will be pushed in indexMatches array till match will return null.
	 }
	 
	  while (match_key = regExp_search_key.exec(content))		// The exec() method returns the matched text if it finds a match, otherwise it returns null.
	 {
      		  indexMatches_key.push(match_key.index);	// Index of match (required search (_nlm fwb)) will be pushed in indexMatches array till match will return null.
	 }
	 
	//console.log(indexMatches_value);			// Display index of required search (_nlm fwb).
	//console.log(indexMatches_key);	

var current_settings =[];	

	var final_value_1 = get_who_can_post_on_your_timeline(content, indexMatches_value[0], indexMatches_key[0]);   // Function Call for first value 
current_settings.push(final_value_1);

	var final_value_2= get_review_posts_that_friends_tag_you_in_before_they_appear_on_your_timeline(content, indexMatches_value[1], indexMatches_key[1]); // Function Call for second value
current_settings.push(final_value_2);

	var final_value_3= get_who_can_see_posts_you_have_been_tagged_in_on_your_timeline(content, indexMatches_value[3], indexMatches_key[3]);	// Function Call for third value
current_settings.push(final_value_3);

	var final_value_4 = get_who_can_see_what_others_post_on_your_timeline(content, indexMatches_value[4], indexMatches_key[4]); // Function Call for fourth value
current_settings.push(final_value_4);

	var final_value_5 = get_review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_facebook(content, indexMatches_value[5], indexMatches_key[5]); // Function Call for fifth value
current_settings.push(final_value_5);

	var final_value_6 = get_when_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it(content, indexMatches_value[6], indexMatches_key[6]); // Function Call for sixth value
current_settings.push(final_value_6);

	var final_value_7 = get_who_sees_tag_suggestions(content, indexMatches_value[7], indexMatches_key[7]); // Function Call for seventh value
current_settings.push(final_value_7);
	//Index '2' is not taken as they are not required.


var c1="{";
var c2="}";

var str =JSON.parse((c1+current_settings+c2)); 	// Load CurrentPublic as JSON in str.
//var str1 = require( "./RecomPrivacy.json" );	// Load CurrentPublic as JSON in str.

var str1= {"Who_can_post_on_your_Timeline":"Friends","Review_posts_friends_tag_you_in_before_they_appear_on_your_Timeline":"On","Who_can_see_posts_you_have_been_tagged_in_on_your_Timeline":"Friends","Who_can_see_what_others_post_on_your_Timeline":"Friends","Review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_Facebook":"On","When_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it":"Friends","Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded":"Friends"};

console.log("\n");	
console.log(" \t JSON File: Current Settings ");
console.log( str );
console.log("\n\n");				//Displaying the Current privacy Json file

console.log(" \t JSON File: Recommended Settings");
console.log( str1 );	
console.log("\n");			//Displaying the Recommended privacy Json file


var msg;


console.log("\t Comparison of settings \n");
var arr = compare(str, str1);				//Calling the function compare

//-------------------------------MEASUREMENT------------------------------------------

	console.log("---------------MEASUREMENT---------------");
var total = current_settings.length;
		console.log("Total Settings : ");
		console.log(total);
var incorrect = arr.length;
		console.log("Incorrect Settings : ");
		console.log(incorrect);
var correct = total - incorrect;
		console.log("Correct Settings : ");
		console.log(correct);

var ratio = correct/total;
console.log("Ratio = correct/total : ");
console.log(ratio);

if(ratio == 1)
{
	msg="You are safe \n";
	console.log(msg);
	self.port.emit('loaded', [str,str1,msg]);
}
else
{
	if(0 <= ratio && ratio < 0.2)
	{
			msg = "User is at risk \n";
			console.log(msg);
			self.port.emit('loaded', [str,str1,msg]);
		
	}
	if(0.2 <= ratio && ratio < 0.8)
	{
			
			msg = "Current settings are loose \n";
			console.log(msg);
			self.port.emit('loaded', [str,str1,msg]);


	}
	if(0.8 <= ratio && ratio < 1)
	{
			msg = "Current settings are reasonable \n";
			console.log(msg);
			self.port.emit('loaded', [str,str1,msg]);


	}
}


}//main fuction reqListener ()



//Function body for extracting first key value pair
function get_who_can_post_on_your_timeline(content, index_of_value, index_of_key) // To get value of Who can post on your Timeline
{
	var array_value =[];	//To store content of value as an array
	var array_key =[];		//To store content of key as an array (key is "who can see your future posts")
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from 'Who can post on your Timeline' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	//console.log(string_key);				//To Display key

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string
	
	//console.log(string_value);		//To Display key

	var regex11 = new RegExp(',', 'g');
	string_key1 = string_key.replace(regex11, '');
	string_value1 = string_value.replace(regex11, '');
	//console.log(string_key1 );
	//console.log(string_value1);

	var regex22 = new RegExp(' ', 'g');
	string_key11= string_key1.replace(regex22, '_');
	string_value11 = string_value1.replace(regex22, '_');

	string_key2 = string_key11.replace('?', '');

	//console.log(string_key2);
	//console.log(string_value11);

	var dq='"';
	//var dq1=',';
	var final_value_1  = dq+string_key2+dq+":"+dq+string_value11+dq;
	console.log(final_value_1 );
	//fs.appendFile("output_json_privacy.json", final_value_1 );
return final_value_1;


}

function get_review_posts_that_friends_tag_you_in_before_they_appear_on_your_timeline(content, index_of_value, index_of_key)
{	
	var array_value =[];	//To store content of value as an array
	var array_key =[];		//To store content of key as an array (key is "Review posts that friends tag you in before they appear on your Timeline")
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'R' from 'Review posts that friends tag you in before they appear on your Timeline' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	//console.log(string_key);						//To Display key


	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string
	
	//console.log(string_value);		//To Display key
		

	var regex11 = new RegExp(',', 'g');
	string_key1 = string_key.replace(regex11, '');
	string_value1 = string_value.replace(regex11, '');
	//console.log(string_key1 );
	//console.log(string_value1);

	var regex22 = new RegExp(' ', 'g');
	string_key11= string_key1.replace(regex22, '_');
	string_value11 = string_value1.replace(regex22, '_');

	var k = "that_";
	var regex33 = new RegExp(k, 'g');
	string_key22= string_key11.replace(regex33, '');

	string_key2 = string_key22.replace('?', '');
	//console.log(string_key2);
	//console.log(string_value11);

	var dq='"';
	//var dq1=',';
	var final_value_2 = dq+string_key2+dq+":"+dq+string_value11+dq;
	console.log(final_value_2 );
	//fs.appendFile("output_json_privacy.json", final_value_2 );
return final_value_2;
}

function get_who_can_see_posts_you_have_been_tagged_in_on_your_timeline(content, index_of_value, index_of_key)
{
	var array_value =[];	//To store content of value as an array
	var array_key =[];		//To store content of key as an array (key is "Who can see posts you've been tagged in on your Timeline?")
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from 'Who can see posts you've been tagged in on your Timeline?' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	//console.log(string_key);						//To Display key

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string
	
	//console.log(string_value);		//To Display key

	
	var regex11 = new RegExp(',', 'g');
	string_key1 = string_key.replace(regex11, '');
	string_value1 = string_value.replace(regex11, '');
	//console.log(string_key1 );
	//console.log(string_value1);

	var regex22 = new RegExp(' ', 'g');
	string_key11= string_key1.replace(regex22, '_');
	string_value11 = string_value1.replace(regex22, '_');

	var k = "&#039;ve";
	var regex33 = new RegExp(k, 'g');
	string_key22= string_key11.replace(regex33, '_have');
	//string_value22 = string_value11.replace(regex33, '_have');

	string_key2 = string_key22.replace('?', '');
	//console.log(string_key2);
	//console.log(string_value11);

	//"Who_can_see_posts_you&#039;ve_been_tagged_in_on_your_Timeline

	var dq='"';
	//var dq1=',';
	var final_value_3 = dq+string_key2+dq+":"+dq+string_value11+dq;
	console.log(final_value_3 );
	//fs.appendFile("output_json_privacy.json", final_value_3 );
return final_value_3;
}

function get_who_can_see_what_others_post_on_your_timeline(content, index_of_value, index_of_key)
{
	
	var array_value =[];	//To store content of value as an array
	var array_key =[];		//To store content of key as an array (key is "Who can see what others post on your Timeline?")
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from 'Who can see what others post on your Timeline?' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	//console.log(string_key);						//To Display key

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string
	
	//console.log(string_value);		//To Display key
	
	var regex11 = new RegExp(',', 'g');
	string_key1 = string_key.replace(regex11, '');
	string_value1 = string_value.replace(regex11, '');
	//console.log(string_key1 );
	//console.log(string_value1);

	var regex22 = new RegExp(' ', 'g');
	string_key11= string_key1.replace(regex22, '_');
	string_value11 = string_value1.replace(regex22, '_');
	
	string_key2 = string_key11.replace('?', '');
	//console.log(string_key2);
	//console.log(string_value11);

	var dq='"';
	//var dq1=',';
	var final_value_4  = dq+string_key2+dq+":"+dq+string_value11+dq;
	console.log(final_value_4 );
	//fs.appendFile("output_json_privacy.json", final_value_4 );
return final_value_4;
}

function get_review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_facebook(content, index_of_value, index_of_key)
{
	var array_value =[];	//To store content of value as an array
	var array_key =[];		//To store content of key as an array (key is "Review tags people add to your own posts before the tags appear on Facebook?")
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'R' from 'Review tags people add to your own posts before the tags appear on Facebook?' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	//console.log(string_key);						//To Display key

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string
	
	//console.log(string_value);		//To Display key


	var regex11 = new RegExp(',', 'g');
	string_key1 = string_key.replace(regex11, '');
	string_value1 = string_value.replace(regex11, '');
	//console.log(string_key1 );
	//console.log(string_value1);

	var regex22 = new RegExp(' ', 'g');
	string_key11= string_key1.replace(regex22, '_');
	string_value11 = string_value1.replace(regex22, '_');
	
	string_key2 = string_key11.replace('?', '');
	
	//console.log(string_key2);
	//console.log(string_value11);

	var dq='"';
	//var dq1=',';
	var final_value_5  = dq+string_key2+dq+":"+dq+string_value11+dq;
	console.log(final_value_5 );
	//fs.appendFile("output_json_privacy.json", final_value_5 );
return final_value_5;
}

function get_when_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it(content, index_of_value, index_of_key)
{
	var array_value =[];	//To store content of value as an array
	var array_key =[];		//To store content of key as an array (key is "When you're tagged in a post, who do you want to add to the audience if they aren't already in it?
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from 'When you're tagged in a post, who do you want to add to the audience if they aren't already in it? (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	//console.log(string_key);						//To Display key

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string
	
	//console.log(string_value);		//To Display key

	var regex11 = new RegExp(',', 'g');
	string_key1 = string_key.replace(regex11, '');
	string_value1 = string_value.replace(regex11, '');
	//console.log(string_key1 );
	//console.log(string_value1);
	
	var regex22 = new RegExp(' ', 'g');
	string_key11= string_key1.replace(regex22, '_');
	string_value11 = string_value1.replace(regex22, '_');

	//When_you&#039;re_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_aren&#039;t_already_in_it

	var k = "&#039;re";
	var regex33 = new RegExp(k, 'g');
	string_key22= string_key11.replace(regex33, '_are');
	
	var regexk1 = new RegExp("n&#039;t", 'g');
	
	string_key11 = string_key22.replace(regexk1, '_not');
	
	var regexk11 = new RegExp("aren’t", 'g');
	
	string_key11 = string_key11.replace(regexk11, 'are_not');
	
	var regexk = new RegExp("you’re", 'g');
	
	string_key223= string_key11.replace(regexk, 'you_are');

	string_key2 = string_key223.replace('?', '');
	//console.log(string_key2);
	//console.log(string_value11);	

	var dq='"';
	//var dq1=',';
	var final_value_5  = dq+string_key2+dq+":"+dq+string_value11+dq;
	console.log(final_value_5 );
	//fs.appendFile("output_json_privacy.json", final_value_5 );
return final_value_5;
}

function get_who_sees_tag_suggestions(content, index_of_value, index_of_key)
{
	var array_value =[];	//To store content of value as an array
	var array_key =[];		//To store content of key as an array (key is "Who sees tag suggestions when photos that look like you are uploaded?")
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from 'Who sees tag suggestions when photos that look like you are uploaded?' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	//console.log(string_key);						//To Display key

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string
	
	//console.log(string_value);		//To Display key


	var regex11 = new RegExp(',', 'g');
	string_key1 = string_key.replace(regex11, '');
	string_value1 = string_value.replace(regex11, '');
	//console.log(string_key1 );
	//console.log(string_value1);

	var regex22 = new RegExp(' ', 'g');
	string_key11= string_key1.replace(regex22, '_');
	string_value11 = string_value1.replace(regex22, '_');

	string_key2 = string_key11.replace('?', '');
	
	//console.log(string_key2);
	//console.log(string_value11);

	var dq='"';
	//var dq1=',';
	var final_value_5  = dq+string_key2+dq+":"+dq+string_value11+dq;
	console.log(final_value_5 );
	//fs.appendFile("output_json_privacy.json", final_value_5 );
return final_value_5;
}

function compare(str, str1)			//Function definition of compare() function
{
	console.log("--------------------COMPARING THE JSON CONTENTS---------------------------");
var arr = [];					//Creating the array
		if(str.Who_can_post_on_your_Timeline == str1.Who_can_post_on_your_Timeline)	 /*Comapring the Json contents of current 													settings and recommended settings*/
		{
			
			console.log(str.Who_can_post_on_your_Timeline,"is equal to",str1.Who_can_post_on_your_Timeline);   /*Displaying the 									Json contents if the current settings and recommended settings are equal*/
			//console.log("\n");
		}
		else
		{
			console.log("\n");
			console.log(str.Who_can_post_on_your_Timeline,"is not equal to",str1.Who_can_post_on_your_Timeline);  /*Displaying 						the Json contents value if the current settings and recommended settings are not equal*/
	
			console.log("\n PUSHING THE VALUE",str.Who_can_post_on_your_Timeline," INTO THE ARRAY");
			arr.push(str.Who_can_post_on_your_Timeline);	/*Pushing the current settings value into 										the array */
			console.log( str.Who_can_post_on_your_Timeline,"IS THE PUSHED VALUE\n");	//Displaying the Pushed value 
		}

		if(str.Review_posts_friends_tag_you_in_before_they_appear_on_your_Timeline == str1.Review_posts_friends_tag_you_in_before_they_appear_on_your_Timeline)  /*Comapring the Json contents next 											value of current settings and recommended settings*/
		{
			console.log(str.Review_posts_friends_tag_you_in_before_they_appear_on_your_Timeline,"is equal to",str1.Review_posts_friends_tag_you_in_before_they_appear_on_your_Timeline); /*Displaying the Json contents if the current settings 												and recommended settings are equal*/
			console.log("\n");
		}
		else
		{
			console.log("\n");
			console.log(str.Review_posts_friends_tag_you_in_before_they_appear_on_your_Timeline,"is not equal to",str1.Review_posts_friends_tag_you_in_before_they_appear_on_your_Timeline);    /*Displaying the Json contents value if the current 												settings and recommended settings are not equal*/
			console.log("\n PUSHING THE VALUE",str.Review_posts_friends_tag_you_in_before_they_appear_on_your_Timeline, "INTO THE ARRAY");
			arr.push(str.Review_posts_friends_tag_you_in_before_they_appear_on_your_Timeline);   /*Pushing the current 													settings value into the array */
			console.log( str.Review_posts_friends_tag_you_in_before_they_appear_on_your_Timeline,"IS THE PUSHED VALUE\n");	//Displaying the Pushed value 
		
		}

		if(str.Who_can_see_posts_you_have_been_tagged_in_on_your_Timeline == str1.Who_can_see_posts_you_have_been_tagged_in_on_your_Timeline)    /*Comapring the Json contents next 									    value of current settings and recommended settings*/
			{

				
				console.log(str.Who_can_see_posts_you_have_been_tagged_in_on_your_Timeline,"is equal to",str1.Who_can_see_posts_you_have_been_tagged_in_on_your_Timeline);	 /*Displaying the Json contents if the current settings and 										recommended settings are equal*/
				console.log("\n");
			}
			else
			{
				console.log("\n");
				console.log(str.Who_can_see_posts_you_have_been_tagged_in_on_your_Timeline,"is not equal to",str1.Who_can_see_posts_you_have_been_tagged_in_on_your_Timeline);	/*Displaying the Json contents value if the current settings and 										recommended settings are not equal*/
				console.log("\n PUSHING THE VALUE",str.Who_can_see_posts_you_have_been_tagged_in_on_your_Timeline ,"INTO THE ARRAY");
				arr.push(str.Who_can_see_posts_you_have_been_tagged_in_on_your_Timeline);	/*Pushing the current 														settings value into the array */
				console.log( str.Who_can_see_posts_you_have_been_tagged_in_on_your_Timeline,"IS THE PUSHED VALUE\n");
												//Displaying the Pushed value
			}

		if(str.Who_can_see_what_others_post_on_your_Timeline == str1.Who_can_see_what_others_post_on_your_Timeline)/*Comapring the 									Json contents next value of current settings and recommended settings*/
		{
				console.log(str.Who_can_see_what_others_post_on_your_Timeline,"is equal to",str1.Who_can_see_what_others_post_on_your_Timeline);	 /*Displaying the Json contents if the current settings and recommended 								settings are equal*/
				console.log("\n");
		}
		else
		{
			console.log("\n");
			console.log(str.Who_can_see_what_others_post_on_your_Timeline,"is not equal to",str1.Who_can_see_what_others_post_on_your_Timeline);	/*Displaying the Json contents value if the current settings and 									recommended settings are not equal*/
			console.log("\n PUSHING THE VALUE",str.Who_can_see_what_others_post_on_your_Timeline ,"INTO THE ARRAY");
			arr.push(str.Who_can_see_what_others_post_on_your_Timeline);	/*Pushing the current 												settings value into the array */
			console.log( str.Who_can_see_what_others_post_on_your_Timeline,"IS THE PUSHED VALUE");
												//Displaying the Pushed value	
		}
		
		if(str.Review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_Facebook== str1.Review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_Facebook)   /*Comapring the Json contents next 											    value of current settings and recommended settings*/
		{
			

			console.log(str.Review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_Facebook,"is equal to",str1.Review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_Facebook);	 /*Displaying the Json contents if the current 												settings and recommended settings are equal*/
			console.log("\n");
		}
		else
		{
			console.log("\n");
			console.log(str.Review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_Facebook,"is not equal to",str1.Review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_Facebook);	/*Displaying the Json contents value if the current 												settings and recommended settings are not equal*/
			console.log("\n PUSHING THE VALUE",str.Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded,"INTO THE ARRAY");
			arr.push(str.Review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_Facebook);/*Pushing the current 													settings value into the array */
			console.log( str.Review_tags_people_add_to_your_own_posts_before_the_tags_appear_on_Facebook,"IS THE PUSHED VALUE\n");	//Displaying the Pushed value
		
		}


			if(str.When_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it == str1.When_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it)  /*Comapring the Json contents next value of current settings and recommended settings*/
		{
			

			console.log(str.When_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it,"is equal to",str1.When_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it);	 /*Displaying the Json 									contents if the current settings and recommended settings are equal*/
			console.log("\n");
		}
		else
		{
			console.log("\n");
			console.log(str.When_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it,"is not equal to",str1.When_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it);	/*Displaying the Json 								contents value if the current settings and recommended settings are not equal*/
			console.log("\n PUSHING THE VALUE",str.When_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it ,"INTO THE ARRAY");
			arr.push(str.When_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it);
										/*Pushing the current settings value into the array */
			console.log( str.When_you_are_tagged_in_a_post_who_do_you_want_to_add_to_the_audience_if_they_are_not_already_in_it,"IS THE PUSHED VALUE\n");
												//Displaying the Pushed value		
		}

if(str.Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded== str1.Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded)  /*Comapring the Json contents next 										    value of current settings and recommended settings*/
		{

			console.log(str.Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded,"is equal to",str1.Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded); /*Displaying the Json contents if the current settings and 											recommended settings are equal*/
			console.log("\n");
		}
		else
		{
			console.log("\n");
			console.log(str.Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded,"is not equal to",str1.Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded);	/*Displaying the Json contents value if the current 											settings and recommended settings are not equal*/
			console.log("\n PUSHING THE VALUE",str.Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded,"INTO THE ARRAY");
			arr.push(str.Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded);/*Pushing the current 														settings value into the array */
			console.log( str.Who_sees_tag_suggestions_when_photos_that_look_like_you_are_uploaded,"IS THE PUSHED VALUE\n");
													//Displaying the Pushed value	
		}

		console.log("\n------------------------DISPLAYING THE ARRAY CONTENTS-----------------------");
		console.log("ARRAY VALUES ARE : ",arr);
		console.log("\n");
return arr;
}

var oReq = new XMLHttpRequest();
oReq.addEventListener("load", reqListener);
oReq.open("GET", "https://www.facebook.com/settings?tab=timeline");
oReq.send();

console.log("REQUEST HAS SENT.................");


