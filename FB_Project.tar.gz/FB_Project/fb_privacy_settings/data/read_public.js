
function reqListener () 
{
var content = this.responseText;
 
console.log("\n");
var search_key1 = "mlm fbSettingsSectionsItemName lfloat _ohe";		//Search for the Key using this class for first key only
var search_value1 ="55pe"; 		//Search for the value using this class for first value only
//var search_key = "bSettingsListItemContent fcg";


var index_of_key = content.search(search_key1); 		//Using this function index of that string can be retrieved
var index_of_value = content.indexOf(search_value1); 		//Using this function index of that string can be retrieved

var search_value = "<strong";					//Search for the Key using this class for other keys
var search_key = "pls fbSettingsListItemLabel"; 		//Search for the value using this class for other values

var match_value, indexMatches_value = [];
var match_key, indexMatches_key  = [];

var regExp_search_value = new RegExp(search_value, "gi"); // RegExp used to search pattern, syntax (pattern, modifiers) g - Perform a global match (find all matches rather than stopping after the first match) i - Perform case-insensitive matching
var regExp_search_key = new RegExp(search_key, "gi"); 

	
var array_value=(content.match(regExp_search_value)); 		// The match() method searches a string for a match against a regular expression, and returns the matches, as an Array object.

var array_key=(content.match(regExp_search_key)); 	



	 while (match_value = regExp_search_value.exec(content))		// The exec() method returns the matched text if it finds a match, otherwise it returns null.
	 {
      		  indexMatches_value.push(match_value.index);	// Index of match (required search (<strong)) will be pushed in indexMatches array till match will return null.
	 }
 //console.log(indexMatches_value1);
	 
	  while (match_key = regExp_search_key.exec(content))		// The exec() method returns the matched text if it finds a match, otherwise it returns null.
	 {
      		  indexMatches_key.push(match_key.index);	// Index of match (required search (pls fbSettingsListItemLabel)) will be pushed in indexMatches array till match will return null.
	 }
	
var current_settings=[];	

	var final_value_1 = get_who_can_follow_me(content,index_of_key,index_of_value); // Function Call for first Key value pair
current_settings.push(final_value_1);
		
	var final_value_2 = get_public_posts_comments(content, indexMatches_key[0], indexMatches_value[0]);   // Function Call for second Key value pair
current_settings.push(final_value_2);
	var final_value_3 = get_public_post_notifications(content, indexMatches_key[1], indexMatches_value[1]); // Function Call for third Key value pair
current_settings.push(final_value_3);
	var final_value_4 = get_public_profile_info(content, indexMatches_key[2], indexMatches_value[2]);	// Function Call for fourth Key value pair
current_settings.push(final_value_4);
	var final_value_5 = get_comment_ranking(content, indexMatches_key[3], indexMatches_value[3]); // Function Call for fifth Key value pair
current_settings.push(final_value_5);
	var final_value_6 = get_Username(content, indexMatches_key[4], indexMatches_value[4]); // Function Call for sixth Key value pair
current_settings.push(final_value_6);

var c1="{";
var c2="}";

var str =JSON.parse((c1+current_settings+c2)); 	// Load CurrentPublic as JSON in str.

var str1= {"Who_Can_Follow_Me":"Friends","Public_Post_Comments":"Friends","Public_Post_Notifications":"Nobody","Public_Profile_Info":"Friends","Comment_Ranking":"Off"};

console.log("\n");	
console.log(" \t JSON File: Current Settings ");
console.log( str );
console.log("\n\n");				//Displaying the Current privacy Json file

console.log(" \t JSON File: Recommended Settings");
console.log( str1 );	
console.log("\n\n");			//Displaying the Recommended privacy Json file


var msg;


console.log("\t Comparison of settings \n");
var arr = compare(str, str1);				//Calling the function compare

//-------------------------------MEASUREMENT------------------------------------------

	console.log("-----------MEASUREMENT----------");
var total = current_settings.length;
		console.log("Total Settings : ");
		console.log(total);
var incorrect = arr.length;
		console.log("Incorrect Settings : ");
		console.log(incorrect);
var correct = total - incorrect;
		console.log("Correct Settings : ");
		console.log(correct);

var ratio = correct/total;
console.log("Ratio = correct/total : ");
console.log(ratio);

if(ratio == 1)
{
	msg="You are safe \n";
	console.log(msg);
	self.port.emit('loaded', [str,str1,msg]);
}
else
{
	if(0 <= ratio && ratio < 0.2)
	{
			msg = "User is at risk \n";
			console.log(msg);
			self.port.emit('loaded', [str,str1,msg]);
		
	}
	if(0.2 <= ratio && ratio < 0.8)
	{
			
			msg = "Current settings are loose \n";
			console.log(msg);
			self.port.emit('loaded', [str,str1,msg]);


	}
	if(0.8 <= ratio && ratio < 1)
	{
			msg = "Current settings are reasonable \n";
			console.log(msg);
			self.port.emit('loaded', [str,str1,msg]);


	}
}

}//main fuction reqListener ()


//Function body for extracting first key value pair
function get_who_can_follow_me(content, index_of_key_first,index_of_value_first) // To get value of who can follow me
{
	var array_value =[];	//To store content of value as an array
	var array_key =[];		//To store content of key as an array (key is "who can see your future posts")
	var flag = 0 ;
	
	//Used to extract key
	while(content[index_of_key_first] != '>')	//To get the starting index of the Key i.e 'w' from "who can follow me?" 
	{
		index_of_key_first++;
	}
	
	while(content[++index_of_key_first] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key_first]);	//Store that char variable in string array like w,h,o .....
	}
	
	var string_key = array_key.join();			//Convert that string array to a string "w,h,o c,a,n....."
	
	//Used to extract value 
	/*do
	{
		if (content[index_of_value_first] != '>')	
		{
			index_of_value_first++;
		}
		else if(content[index_of_value_first] == '>')
		{
			flag++;
			index_of_value_first++;
		}
		
	}while(flag != 3)*/	

	//console.log(content[index_of_value_first]);
	while(content[index_of_value_first] != '>')		
	{
		//console.log(content[index_of_value_first]);
		index_of_value_first++;
	}
	
	index_of_value_first++;	
	while(content[index_of_value_first] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
	//console.log(content[index_of_value_first]);
		array_value.push(content[index_of_value_first]);		//Store content value into the array
		index_of_value_first++;
	}
	
	var string_value = array_value.join();				//converting array into string
	
	//console.log(string_value);
	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	//Converting to JSON format
	var dq='"';	
	var final_value_1  = dq+string_key11+dq+":"+dq+string_value11+dq+"\n";
	
	console.log(final_value_1 );

return final_value_1;		
}

//Function body for extracting second key value pair
function get_public_posts_comments(content, index_of_key, index_of_value) // To get value of public posts comments
{
	var array_key =[];	//To store content of key as an array (key is "public post comments")
	var array_value =[];	//To store content of value as an array
	
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'P' from 'public posts comments' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'P' from 'Public'(moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string

	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	//Converting to JSON format
	var dq='"';	
	var final_value_2  = dq+string_key11+dq+":"+dq+string_value11+dq+"\n";
	
	console.log(final_value_2);

return final_value_2;


}

//Function body for extracting third key value pair
function get_public_post_notifications(content, index_of_key, index_of_value)
{	
	var array_key =[];	//To store content of key as an array (key is "pubic post notifications")
	var array_value =[];	//To store content of value as an array
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'P' from 'Public Post notifications' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	//console.log(string_key);						//To Display key


	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'P' from 'Public'(moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string
	
	//console.log(string_value);		//To Display key
		

	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	//Converting to JSON format
	var dq='"';	
	var final_value_3  = dq+string_key11+dq+":"+dq+string_value11+dq+"\n";
	
	console.log(final_value_3 );

return final_value_3;
}

//Function body for extracting fourth key value pair
function get_public_profile_info(content, index_of_key, index_of_value)
{
	var array_key =[];	//To store content of key as an array (key is "Public profile info")
	var array_value =[];	//To store content of value as an array
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'P' from 'Public profile info' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'P' from 'Public'(moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string


	
	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	//Converting to JSON format
	var dq='"';	
	var final_value_4  = dq+string_key11+dq+":"+dq+string_value11+dq+"\n";
	
	console.log(final_value_4 );

return final_value_4;
}

//Function body for extracting fifth key value pair
function get_comment_ranking(content,index_of_key, index_of_value)
{
	
	var array_key =[];	//To store content of key as an array (key is "Comment ranking")
	var array_value =[];	//To store content of value as an array
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'C' from 'Comment ranking' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string


	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'O' from 'On/Off' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string

	
	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	//Converting to JSON format
	var dq='"';	
	var final_value_5  = dq+string_key11+dq+":"+dq+string_value11+dq+"\n";
	
	console.log(final_value_5 );

return final_value_5;
}

//Function body for extracting sixth key value pair
function get_Username(content, index_of_key, index_of_value)
{
	var array_key =[];		//To store content of key as an array (key is "Username")
	var array_value =[];		//To store content of value as an array

	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'U' from 'Username' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 't' from 'tenvi.shinde'(moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string

	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	//Converting to JSON format
	var dq='"';	
	var final_value_6  = dq+string_key11+dq+":"+dq+string_value11+dq+"\n";
	
	console.log(final_value_6 );

return final_value_6;
}

function compare(str,str1)			//Function definition of compare() function
{
	console.log("--------------------COMPARING THE JSON CONTENTS---------------------------");
	var arr = [];					//Creating the array
		if(str.Who_Can_Follow_Me == str1.Who_Can_Follow_Me)/*Comapring the Json contents of current
								   settings and recommended settings*/
		{
			
			console.log(str.Who_Can_Follow_Me,"is equal to",str1.Who_Can_Follow_Me);/*Displaying the 													Json contents if the current settings and 													recommended settings are equal*/
					
			//console.log("\n");
		}
		else
		{
			console.log("\n");
			console.log(str.Who_Can_Follow_Me,"is not equal to",str1.Who_Can_Follow_Me);/*Displaying the Json contents value if 													    the current settings and recommended 													    settings are not equal*/

			console.log("\n PUSHING THE VALUE",str.Who_Can_Follow_Me," INTO THE ARRAY");/*Pushing the current settings value 													      into the array */

			arr.push(str.Who_Can_Follow_Me);
			console.log( str.Who_Can_Follow_Me,"IS THE PUSHED VALUE\n");//Displaying the Pushed value
		}

		if(str.Public_Post_Comments == str1.Public_Post_Comments)/*Comapring the Json contents next 										 value of current settings and recommended settings*/
		{
			

			console.log(str.Public_Post_Comments,"is equal to",str1.Public_Post_Comments);/*Displaying 							the Json contents value if the current settings and recommended settings are not equal*/

			console.log("\n");
		}
		else
		{
			console.log("\n");
			console.log(str.Public_Post_Comments,"is not equal to",str1.Public_Post_Comments);/*Displaying the Json contents 									  value if the current settings and recommended settings are not equal*/
			console.log("\n PUSHING THE VALUE",str.Public_Post_Comments, "INTO THE ARRAY");
			arr.push(str.Public_Post_Comments);/*Pushing the current settings value into the array */

			console.log( str.Public_Post_Comments,"IS THE PUSHED VALUE\n");//Displaying the Pushed value
		
		}

		if(str.Public_Post_Notifications == str1.Public_Post_Notifications)/*Comapring the Json contents next 										           value of current settings and recommended settings*/
			{
				
				console.log(str.Public_Post_Notifications,"is equal to",str1.Public_Post_Notifications);/*Displaying the 								Json contents value if the current settings and recommended settings are not equal*/
				console.log("\n");
			}
			else
			{
				
				console.log(str.Public_Post_Notifications,"is not equal to",str1.Public_Post_Notifications);/*Displaying 						       the Json contents value if the current settings and recommended settings are not equal*/	
				console.log("\n PUSHING THE VALUE",str.Public_Post_Notifications ,"INTO THE ARRAY");
				arr.push(str.Public_Post_Notifications); /*Pushing the current settings value into the array */
				console.log( str.Public_Post_Notifications,"IS THE PUSHED VALUE\n"); //Displaying the Pushed value
			}

		if(str.Public_Profile_Info == str1.Public_Profile_Info)/*Comapring the Json contents next 										value of current settings and recommended settings*/
		{
				console.log(str.Public_Profile_Info,"is equal to",str1.Public_Profile_Info);/*Displaying the Json contents 									value if the current settings and recommended settings are not equal*/		
		}
		else
		{
			console.log("\n");
			console.log(str.Public_Profile_Info,"is not equal to",str1.Public_Profile_Info);/*Displaying the Json contents   									value if the current settings and recommended settings are not equal*/
			console.log("\n PUSHING THE VALUE",str.Public_Profile_Info ,"INTO THE ARRAY");
			arr.push(str.Public_Profile_Info);/*Pushing the current settings value into the array */
			console.log( str.Public_Profile_Info,"IS THE PUSHED VALUE");//Displaying the Pushed value
		
		}
	
		if(str.Comment_Ranking == str1.Comment_Ranking)/*Comapring the Json contents next 									value of current settings and recommended settings*/
		{
			console.log(str.Comment_Ranking,"is equal to",str1.Comment_Ranking);/*Displaying the Json contents value if the 										current settings and recommended settings are not equal*/
			console.log("\n");
		}
		else
		{
			console.log("\n");
			console.log(str.Comment_Ranking,"is not equal to",str1.Comment_Ranking);/*Displaying the Json contents value if the 											current settings and recommended settings are not equal*/
			console.log("\n PUSHING THE VALUE",str.Comment_Ranking ,"INTO THE ARRAY");
			arr.push(str.Comment_Ranking);/*Pushing the current settings value into the array */
			console.log( str.Comment_Ranking,"IS THE PUSHED VALUE\n");//Displaying the Pushed value	
		}
	
		console.log("\n------------------------DISPLAYING THE ARRAY CONTENTS-----------------------");
		console.log("ARRAY VALUES ARE : ",arr);//Displaying the array contents
		console.log("\n");
return arr;
}
var oReq = new XMLHttpRequest();
oReq.addEventListener("load", reqListener);
oReq.open("GET", "https://www.facebook.com/settings?tab=followers");
oReq.send();

console.log("REQUEST HAS SENT.................");


