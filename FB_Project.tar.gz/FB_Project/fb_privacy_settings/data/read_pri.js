
function reqListener () 
{

var content = this.responseText;
//console.log(content);
console.log("\n");

var search_value = "_nlm fwb";
var search_key = "_nll";
var match_value, indexMatches_value = [];
var match_key, indexMatches_key  = [];

var regExp_search_value = new RegExp(search_value, "gi"); // RegExp used to search pattern, syntax (pattern, modifiers) g - Perform a global match (find all matches rather than stopping after the first match) i - Perform case-insensitive matching

var regExp_search_key = new RegExp(search_key, "gi"); 
	
var array_value=(content.match(regExp_search_value)); 		// The match() method searches a string for a match against a regular expression, and returns the matches, as an Array object.

var array_key=(content.match(regExp_search_key)); 	

	 while (match_value = regExp_search_value.exec(content))		// The exec() method returns the matched text if it finds a match, otherwise it returns null.
	 {
      		  indexMatches_value.push(match_value.index);	// Index of match (required search (_nlm fwb)) will be pushed in indexMatches array till match will return null.
	 }
	 
	  while (match_key = regExp_search_key.exec(content))		// The exec() method returns the matched text if it finds a match, otherwise it returns null.
	 {
      		  indexMatches_key.push(match_key.index);	// Index of match (required search (_nlm fwb)) will be pushed in indexMatches array till match will return null.
	 }
	 
	//console.log(indexMatches);			// Display index of required search (_nlm fwb).
	//console.log(indexMatches2);	
var current_settings =[];	
		
	var final_value_1 = get_who_can_see_your_future_posts(content, indexMatches_key[0], indexMatches_value[0]);   // Function Call for first value __
current_settings.push(final_value_1);
	var final_value_2= get_Who_can_see_your_friends_list(content, indexMatches_key[1], indexMatches_value[1]); // Function Call for second value
current_settings.push(final_value_2);
	var final_value_3= get_who_can_send_you_freind_request(content, indexMatches_key[4], indexMatches_value[4]); // Function Call for second value
current_settings.push(final_value_3);
	var final_value_4= get_who_can_look_you_up_using_email(content, indexMatches_key[5], indexMatches_value[5]);	// Function Call for third value
current_settings.push(final_value_4);
	var final_value_5 = get_who_can_look_you_up_using_phone_no(content, indexMatches_key[6], indexMatches_value[6]); // Function Call for fourth value
current_settings.push(final_value_5);
	var final_value_6 = get_value_of_search_engine_to_link_profile_outside_facebook(content, indexMatches_key[7], indexMatches_value[7]); // Function Call for fifth value
current_settings.push(final_value_6);

//Index '1' and '2' are not taken as they are not required.

var c1="{"; //For JSON format
var c2="}"; //For JSON format

var str =JSON.parse((c1+current_settings+c2)); 	// Load CurrentPublic as JSON in str.
//var str1 = require( "./RecomPrivacy.json" );	// Load CurrentPublic as JSON in str.

//Recommended privacy settings
var str1={"Who_can_see_your_future_posts":"Friends","Who_can_see_your_friends_list":"Friends","Who_can_send_you_friend_requests":"Friends_of_friends","Who_can_look_you_up_using_the_email_address_you_provided":"Friends","Who_can_look_you_up_using_the_phone_number_you_provided":"Friends","Do_you_want_search_engines_outside_of_Facebook_to_link_to_your_Profile":"No"};

console.log("\n");	
console.log(" \t JSON File: Current Settings ");
console.log( str );
console.log("\n");				//Displaying the Current privacy Json file

console.log(" \t JSON File: Recommended Settings");
console.log( str1 );	
console.log("\n");			//Displaying the Recommended privacy Json file

var msg;

console.log("\t Comparison of settings \n");
var arr = compare(str, str1);				//Calling the function compare

//-------------------------------MEASUREMENT------------------------------------------

console.log("---------------MEASUREMENT---------------");
var total = current_settings.length;
		console.log("Total Settings : ");
		console.log(total);
var incorrect = arr.length;
		console.log("Incorrect Settings : ");
		console.log(incorrect);
var correct = total - incorrect;
		console.log("Correct Settings : ");
		console.log(correct);

var ratio = correct/total;
console.log("Ratio = correct/total : ");
console.log(ratio);

if(ratio == 1)
{
	msg="You are safe \n";
	console.log(msg);
	self.port.emit('loaded', [str,str1,msg]);
}
else
{
	if(0 <= ratio && ratio < 0.2)
	{
			msg = "User is at risk \n";
			console.log(msg);
			self.port.emit('loaded', [str,str1,msg]);
		
	}
	if(0.2 <= ratio && ratio < 0.8)
	{
			
			msg = "Current settings are loose \n";
			console.log(msg);
			self.port.emit('loaded', [str,str1,msg]);


	}
	if(0.8 <= ratio && ratio < 1)
	{
			msg = "Current settings are reasonable \n";
			console.log(msg);
			self.port.emit('loaded', [str,str1,msg]);


	}
}

}//main fuction reqListener ()


//Function body for extracting first key value pair
function get_who_can_see_your_future_posts(content, index_of_key, index_of_value) // To get value of who can see your future posts
{
	var array_key =[];		//To store content of key as an array (key is "who can see your future posts")
	var array_value =[];		//To store content of value as an array
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from 'who can see your fuuture posts' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	//console.log(string_key);				//To Display key

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string
	

	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	var string_key111 = string_key11.replace('?', '');

	//Converting to JSON format
	var dq='"';	
	var final_value_1  = dq+string_key111+dq+":"+dq+string_value11+dq;
	
	console.log(final_value_1 );

return final_value_1;
}



function get_Who_can_see_your_friends_list(content, index_of_key, index_of_value)
{	
	var array_key =[];		//To store content of key as an array (key is "Who can see your friends list")
	var array_value =[];		//To store content of value as an array
		
	while(content[index_of_key] != '<')		// Getting index to desired location i.e 'W' from 'Who can see your friends list '  (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from '' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string

	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	var string_key111 = string_key11.replace('?', '');

	//Converting to JSON format
	var dq='"';	
	var final_value_2  = dq+string_key111+dq+":"+dq+string_value11+dq;
	
	console.log(final_value_2);

return final_value_2;
		
}





//Function body for extracting second key value pair
function get_who_can_send_you_freind_request(content, index_of_key, index_of_value)
{	
	var array_key =[];		//To store content of key as an array (key is "who can send you freind request")
	var array_value =[];		//To store content of value as an array
		
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from 'who can see your fuuture posts' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string

	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	var string_key111 = string_key11.replace('?', '');

	//Converting to JSON format
	var dq='"';	
	var final_value_2  = dq+string_key111+dq+":"+dq+string_value11+dq;
	
	console.log(final_value_2);

return final_value_2;
		
}

//Function body for extracting third key value pair
function get_who_can_look_you_up_using_email(content, index_of_key, index_of_value)
{
	var array_key =[];		//To store content of key as an array (key is "who can look you up using email")
	var array_value =[];		//To store content of value as an array
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from 'who can see your fuuture posts' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string

	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	var string_key111 = string_key11.replace('?', '');

	//Converting to JSON format
	var dq='"';	
	var final_value_3  = dq+string_key111+dq+":"+dq+string_value11+dq;
	
	console.log(final_value_3 );

return final_value_3;
		
}

//Function body for extracting fourth key value pair
function get_who_can_look_you_up_using_phone_no(content, index_of_key, index_of_value)
{
	var array_key =[];		//To store content of key as an array (key is "who can look you up using phone no")
	var array_value =[];		//To store content of value as an array
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from 'who can see your fuuture posts' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string

	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string

	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	var string_key111 = string_key11.replace('?', '');

	//Converting to JSON format
	var dq='"';	
	var final_value_4  = dq+string_key111+dq+":"+dq+string_value11+dq;
	
	console.log(final_value_4 );

return final_value_4;
		
}

//Function body for extracting fifth key value pair
function get_value_of_search_engine_to_link_profile_outside_facebook(content, index_of_key, index_of_value)
{
	var array_key =[];		//To store content of key as an array (key is "value of search engine to link profile outside facebook")
	var array_value =[];	//To store content of value as an array
	
	while(content[index_of_key] != '>')		// Getting index to desired location i.e 'W' from 'who can see your fuuture posts' (moving ahead/ removing unwanted)
	{
		index_of_key++;
	}
	
	while(content[++index_of_key] != '<')		// To get key within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_key.push(content[index_of_key]);		//Push content key into the array
	}
	
	var string_key = array_key.join();				//converting array into string
	
	while(content[index_of_value] != '>')	// Getting index to desired location i.e 'F' from 'Friends/Freinds of Friends' or 'O' from 'only me' (moving ahead/ removing unwanted)
	{
		index_of_value++;
	}
	
	while(content[++index_of_value] != '<')		// To get value within '< >.....< > 'tag (Reqiured '.....' value)
	{
		array_value.push(content[index_of_value]);
	}
	
	var string_value = array_value.join();		//converting array into string
	
	//For removing comma from a key and value pair
	var regex11 = new RegExp(',', 'g');
	var string_key1 = string_key.replace(regex11, '');
	var string_value1 = string_value.replace(regex11, '');

	//Replacing blank spaces with underscore 
	var regex22 = new RegExp(' ', 'g');
	var string_key11= string_key1.replace(regex22, '_');
	var string_value11 = string_value1.replace(regex22, '_');

	var string_key111 = string_key11.replace('?', '');

	//Converting to JSON format
	var dq='"';	
	var final_value_5  = dq+string_key111+dq+":"+dq+string_value11+dq;
	
	console.log(final_value_5 );

return final_value_5;
		
}

function compare(str, str1)			//Function definition of compare() function
{
	//console.log("Output:"+str);
	//console.log("Recom:"+str1);
	console.log("\t --------------------COMPARING THE JSON CONTENTS---------------------------");
	var arr = [];					//Creating the array
		if(str.Who_can_see_your_future_posts == str1.Who_can_see_your_future_posts)	/*Comapring the Json contents of current
												 settings and recommended settings*/
		{
			
			console.log(str.Who_can_see_your_future_posts,"is equal to",str1.Who_can_see_your_future_posts);  /*Displaying the 									Json contents if the current settings and recommended settings are equal*/
			//console.log("\n");
		}
		else
		{
			//console.log("\n");
			console.log(str.Who_can_see_your_future_posts,"is not equal to",str1.Who_can_see_your_future_posts);  /*Displaying 							the Json contents value if the current settings and recommended settings are not equal*/

			console.log("\t PUSHING THE ELEMENT",str.Who_can_see_your_future_posts," INTO THE ARRAY");
			arr.push(str.Who_can_see_your_future_posts);				/*Pushing the current settings value into 													the array */

			//console.log( str.Who_can_see_your_future_posts,"IS THE PUSHED VALUE\n");	//Displaying the Pushed value  
		}










		if(str.Who_can_see_your_friends_list == str1.Who_can_see_your_friends_list)	/*Comapring the Json contents next 												value of current settings and recommended settings*/
		{
			

			console.log(str.Who_can_see_your_friends_list,"is equal to",str1.Who_can_see_your_friends_list); /*Displaying 							the Json contents value if the current settings and recommended settings are not equal*/
	
		}
		else
		{
			//console.log("\n");
			console.log(str.Who_can_see_your_friends_list,"is not equal to",str1.Who_can_see_your_friends_list);/*Displaying the Json contents value if the current settings and recommended settings are not equal*/

			console.log("PUSHING THE ELEMENT",str.Who_can_see_your_friends_list, "INTO THE ARRAY");
			arr.push(str.Who_can_see_your_friends_list);				/*Pushing the current settings value into 													the array */

			//console.log( str.Who_can_send_you_friend_requests,"IS THE PUSHED ELEMENT\n");	//Displaying the Pushed value
		
		}

	











		if(str.Who_can_send_you_friend_requests == str1.Who_can_send_you_friend_requests)	/*Comapring the Json contents next 												value of current settings and recommended settings*/
		{
			

			console.log(str.Who_can_send_you_friend_requests,"is equal to",str1.Who_can_send_you_friend_requests); /*Displaying 							the Json contents value if the current settings and recommended settings are not equal*/
	
		}
		else
		{
			//console.log("\n");
			console.log(str.Who_can_send_you_friend_requests,"is not equal to",str1.Who_can_send_you_friend_requests);/*Displaying the Json contents value if the current settings and recommended settings are not equal*/

			console.log("PUSHING THE ELEMENT",str.Who_can_send_you_friend_requests, "INTO THE ARRAY");
			arr.push(str.Who_can_send_you_friend_requests);				/*Pushing the current settings value into 													the array */

			//console.log( str.Who_can_send_you_friend_requests,"IS THE PUSHED ELEMENT\n");	//Displaying the Pushed value
		
		}

		if(str.Who_can_look_you_up_using_the_email_address_you_provided == str1.Who_can_look_you_up_using_the_email_address_you_provided)		/*Comapring the Json contents next 										value of current settings and recommended settings*/
			{
			
				console.log(str.Who_can_look_you_up_using_the_email_address_you_provided,"is equal to",str1.Who_can_look_you_up_using_the_email_address_you_provided);	/*Displaying the Json contents value if the current settings and 										recommended settings are not equal*/
				//console.log("\n");
			}
			else
			{
				
				console.log(str.Who_can_look_you_up_using_the_email_address_you_provided,"is not equal to",str1.Who_can_look_you_up_using_the_email_address_you_provided);	/*Displaying the Json contents value if the current settings and 										recommended settings are not equal*/

				console.log("\t PUSHING THE VALUE",str.Who_can_look_you_up_using_the_email_address_you_provided ,"INTO THE ARRAY");
				arr.push(str.Who_can_look_you_up_using_the_email_address_you_provided);   /*Pushing the current settings 														value into the array */
				//console.log( str.Who_can_look_you_up_using_the_email_address_you_provided,"IS THE PUSHED VALUE\n"); //Displaying the Pushed value
			}

		if(str.Who_can_look_you_up_using_the_phone_number_you_provided == str1.Who_can_look_you_up_using_the_phone_number_you_provided)		/*Comapring the Json contents next 										value of current settings and recommended settings*/
		{
				console.log(str.Who_can_look_you_up_using_the_phone_number_you_provided,"is equal to",str1.Who_can_look_you_up_using_the_phone_number_you_provided);	/*Displaying the Json contents value if the current settings and 										recommended settings are not equal*/		
		}
		else
		{
			//console.log("\n");
			console.log(str.Who_can_look_you_up_using_the_phone_number_you_provided,"is not equal to",str1.Who_can_look_you_up_using_the_phone_number_you_provided);	/*Displaying the Json contents value if the current settings and 										recommended settings are not equal*/
			console.log("\t PUSHING THE VALUE",str.Who_can_look_you_up_using_the_phone_number_you_provided ,"INTO THE ARRAY");
			arr.push(str.Who_can_look_you_up_using_the_phone_number_you_provided); /*Pushing the current settings 														value into the array */
			//console.log( str.Who_can_look_you_up_using_the_phone_number_you_provided,"IS THE PUSHED ELEMENT");//Displaying the Pushed value
		
		}

		if(str.Do_you_want_search_engines_outside_of_Facebook_to_link_to_your_Profile == str1.Do_you_want_search_engines_outside_of_Facebook_to_link_to_your_Profile)	/*Comapring the Json contents next 										value of current settings and recommended settings*/
		{
			

			console.log(str.Do_you_want_search_engines_outside_of_Facebook_to_link_to_your_Profile,"is equal to",str1.Do_you_want_search_engines_outside_of_Facebook_to_link_to_your_Profile);	/*Displaying the Json contents value if the current settings and 										recommended settings are not equal*/
			//console.log("\n");
		}
		else
		{
			//console.log("\n");
			console.log(str.Do_you_want_search_engines_outside_of_Facebook_to_link_to_your_Profile,"is not equal to",str1.Do_you_want_search_engines_outside_of_Facebook_to_link_to_your_Profile); /*Displaying the Json contents value if the current 											settings and recommended settings are not equal*/
			console.log("\t PUSHING THE VALUE", str.Do_you_want_search_engines_outside_of_Facebook_to_link_to_your_Profile, "INTO THE ARRAY");
			arr.push(str.Do_you_want_search_engines_outside_of_Facebook_to_link_to_your_Profile);/*Pushing the current settings 														value into the array */
			//console.log( str.Do_you_want_search_engines_outside_of_Facebook_to_link_to_your_Profile,"IS THE PUSHED VALUE\n");//Displaying the Pushed value
		
		}
	
		console.log("\t ------------------------DISPLAYING THE ARRAY CONTENTS-----------------------");
		console.log("ARRAY ELEMENTS ARE : ",arr+"\n");		//Displaying the array contents
		//console.log("\n");
return arr;
}


var oReq = new XMLHttpRequest();
oReq.addEventListener("load", reqListener);
oReq.open("GET", "https://www.facebook.com/settings?tab=privacy");
oReq.send();

console.log("REQUEST HAS SENT.................");

