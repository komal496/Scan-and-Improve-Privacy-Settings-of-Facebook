#fb_privacy_settings
Scan and Improve Facebook Privacy Settings
