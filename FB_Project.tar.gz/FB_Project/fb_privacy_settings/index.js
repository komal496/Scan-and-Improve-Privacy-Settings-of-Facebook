"use strict";

var tabs = require("sdk/tabs");
var buttons = require("sdk/ui/button/action");
var self = require("sdk/self");
var data = require("sdk/self").data;
var { ToggleButton } = require('sdk/ui/button/toggle');
var sdkPanels = require("sdk/panel");
var pageMod = require("sdk/page-mod");

buttons.ActionButton({
  id: "Facebook-Privacy-Settings",
  label: "Facebook Privacy Settings",
  icon: "./fb1.png",
  onClick: attachScript
});

function attachScript() {
tabs.open("panel.html");
onOpen(tabs);
function onOpen(tab) {
  console.log(tab.url + " is open");
  tab.on("pageshow", logShow);
  tab.on("activate", logActivate);
  tab.on("deactivate", logDeactivate);
  tab.on("close", logClose);
}

function logShow(tab) {
  console.log(tab.url + " is loaded");
}

function logActivate(tab) {
  console.log(tab.url + " is activated");
}

function logDeactivate(tab) {
  console.log(tab.url + " is deactivated");
}

function logClose(tab) {
  console.log(tab.url + " is closed");
}
}

var current_settings, recommended_settings, msg; 

//scan and compare privacy settings
pageMod.PageMod({
  include: "https://www.facebook.com/settings?tab=privacy",
  contentScriptFile:data.url("./read_pri.js"),
  onAttach: setupListener_privacy
});

//scan and compare timeline settings
pageMod.PageMod({
  include: "https://www.facebook.com/settings?tab=timeline",
  contentScriptFile:data.url("./read_timeline.js"),
  onAttach: setupListener_timeline
});

//scan and compare public posts settings
pageMod.PageMod({
  include: "https://www.facebook.com/settings?tab=followers", //this line will reduce time for loading
  contentScriptFile:data.url("./read_public.js"),
  onAttach: setupListener_publicpost
});



//for displaying message of content-script.js of privacy settings
function setupListener_privacy(worker) 
{
	worker.port.on('loaded', function(pageInfo) 
	{
		current_settings = pageInfo[0];
		recommended_settings = pageInfo[1];
		msg = pageInfo[2] ;

		var worker = tabs.activeTab.attach({
		        contentScriptFile: [
			data.url("display_privacy.js")]
		  });
		  
		worker.port.emit("my-addon-message", msg,current_settings, recommended_settings); //Passing message, Current settings and Recommended settings
	  });
}


//for displaying message of content-script.js of timeline settings
function setupListener_timeline(worker) 
{
	worker.port.on('loaded', function(pageInfo) 
	{
		current_settings = pageInfo[0];
		recommended_settings = pageInfo[1];
		msg = pageInfo[2] ;

		var worker = tabs.activeTab.attach({
		        contentScriptFile: [
			data.url("display_timeline.js")]
		  });
		  
		worker.port.emit("my-addon-message", msg,current_settings, recommended_settings); //Passing message, Current settings and Recommended settings
	  });
}

//for displaying message of content-script.js of public posts settings
function setupListener_publicpost(worker) 
{
	worker.port.on('loaded', function(pageInfo) 
	{
		current_settings = pageInfo[0];
		recommended_settings = pageInfo[1];
		msg = pageInfo[2] ;

		var worker = tabs.activeTab.attach({
		        contentScriptFile: [
			data.url("display_publicpost.js")]
		  });
		  
		worker.port.emit("my-addon-message", msg,current_settings, recommended_settings); //Passing message, Current settings and Recommended settings
	  });
}


